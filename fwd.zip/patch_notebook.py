"""
Full patch script — rewrites PYNQ_Z2_Smart_Surveillance.ipynb for 
HIGH-PERFORMANCE REAL-TIME VIDEO on PYNQ-Z2.
Decouples heavy detection (YOLO/OCR) from smooth display.
"""

import json

NB_PATH = r'E:/ai project/PYNQ_Z2_Smart_Surveillance.ipynb'

# ── CELL 5: Optimised Helpers ──────────────────────────────────────────────────
HELPERS_SRC = [
    "# ══════════════════════════════════════════════════════\n",
    "# CELL 5 — Optimized Helper Functions for Smooth Video\n",
    "# ══════════════════════════════════════════════════════\n",
    "\n",
    "def draw_box(frame, x, y, w, h, label, color):\n",
    "    cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)\n",
    "    lsize, _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 2)\n",
    "    cv2.rectangle(frame, (x, y - lsize[1] - 8), (x + lsize[0] + 4, y), color, -1)\n",
    "    cv2.putText(frame, label, (x + 2, y - 4),\n",
    "                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2)\n",
    "\n",
    "# ── HEAVY: YOLO (all 80 classes) ─────────────────────────\n",
    "def run_yolo(frame):\n",
    "    H, W = frame.shape[:2]\n",
    "    # Resize to 320 for speed (standard YOLO is 416 but PYNQ needs speed)\n",
    "    blob = cv2.dnn.blobFromImage(frame, 1/255.0, (320, 320), swapRB=True, crop=False)\n",
    "    net.setInput(blob)\n",
    "    outs = net.forward(output_layers)\n",
    "    boxes, confs, cids = [], [], []\n",
    "    for out in outs:\n",
    "        for det in out:\n",
    "            scores = det[5:]\n",
    "            cid, conf = np.argmax(scores), float(scores[np.argmax(scores)])\n",
    "            if conf > YOLO_CONFIDENCE:\n",
    "                cx, cy, bw, bh = (det[:4] * [W, H, W, H]).astype(int)\n",
    "                boxes.append([max(0, cx - bw//2), max(0, cy - bh//2), int(bw), int(bh)])\n",
    "                confs.append(conf)\n",
    "                cids.append(cid)\n",
    "    indices = cv2.dnn.NMSBoxes(boxes, confs, YOLO_CONFIDENCE, YOLO_NMS_THRESH)\n",
    "    return [(COCO_CLASSES[cids[i]], confs[i], *boxes[i]) for i in (indices.flatten() if len(indices)>0 else [])]\n",
    "\n",
    "# ── FAST: Motion (MOG2) ──────────────────────────────────\n",
    "def run_motion(frame):\n",
    "    fg = bg_subtractor.apply(frame)\n",
    "    _, fg = cv2.threshold(fg, 200, 255, cv2.THRESH_BINARY)\n",
    "    cnts, _ = cv2.findContours(fg, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)\n",
    "    return [cv2.boundingRect(c) for c in cnts if cv2.contourArea(c) > MOTION_MIN_AREA]\n",
    "\n",
    "# ── HEAVY: REVA Text (Tesseract) ─────────────────────────\n",
    "def run_reva_text(frame):\n",
    "    if not OCR_AVAILABLE: return []\n",
    "    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)\n",
    "    try:\n",
    "        data = pytesseract.image_to_data(gray, output_type=pytesseract.Output.DICT)\n",
    "        return [(data['left'][i], data['top'][i], data['width'][i], data['height'][i], data['text'][i]) \n",
    "                for i in range(len(data['text'])) \n",
    "                if int(data['conf'][i]) > 30 and any(kw.lower() in data['text'][i].lower() for kw in REVA_KEYWORDS)]\n",
    "    except: return []\n",
    "\n",
    "# ── MEDIUM: REVA Logo (ORB) ──────────────────────────────\n",
    "def run_reva_logo(frame):\n",
    "    if logo_des is None: return None\n",
    "    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)\n",
    "    try:\n",
    "        kp2, des2 = orb_detector.detectAndCompute(gray, None)\n",
    "        if des2 is None or len(des2) < 5: return None\n",
    "        matches = sorted(cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True).match(logo_des, des2), key=lambda x:x.distance)\n",
    "        good = [m for m in matches if m.distance < 60]\n",
    "        if len(good) >= 8:\n",
    "            pts = np.float32([kp2[m.trainIdx].pt for m in good])\n",
    "            x, y = int(pts[:,0].min()), int(pts[:,1].min())\n",
    "            return (x, y, max(60, int(pts[:,0].max())-x), max(60, int(pts[:,1].max())-y))\n",
    "    except: return None\n",
    "\n",
    "# ── FAST DISPLAY ─────────────────────────────────────────\n",
    "def show_in_notebook(frame, frame_count, fps, dhandle=None):\n",
    "    _, buffer = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), 75])\n",
    "    img_data = buffer.tobytes()\n",
    "    if dhandle is None:\n",
    "        dhandle = display(Image(data=img_data), display_id=True)\n",
    "    else:\n",
    "        dhandle.update(Image(data=img_data))\n",
    "    return dhandle\n",
    "\n",
    "print('✅ Optimized helpers ready!')\n"
]

# ── CELL 6: High-Performance Main Loop ─────────────────────────────────────────
MAIN_SRC = [
    "# ══════════════════════════════════════════════════════\n",
    "# CELL 6 — High-Performance Live Video Loop\n",
    "# ══════════════════════════════════════════════════════\n",
    "\n",
    "def run_surveillance(max_frames=MAX_FRAMES):\n",
    "    cap = cv2.VideoCapture(CAMERA_INDEX)\n",
    "    if not cap.isOpened(): return print('ERROR: Camera failed')\n",
    "    \n",
    "    cap.set(cv2.CAP_PROP_FRAME_WIDTH, FRAME_WIDTH)\n",
    "    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT)\n",
    "    \n",
    "    # --- Persistent Detection State ---\n",
    "    cache = {'yolo': [], 'text': [], 'logo': None, 'summary': {}}\n",
    "    \n",
    "    frame_count = 0\n",
    "    prev_time = time.time()\n",
    "    dh = None\n",
    "    \n",
    "    print('🚀 LIVE FEED STARTED! Decoupled AI mode.')\n",
    "    print('   - Video: Smooth Live Feed')\n",
    "    print('   - AI   : Periodic Background Check')\n",
    "\n",
    "    try:\n",
    "        while True:\n",
    "            ret, frame = cap.read()\n",
    "            if not ret: continue\n",
    "            frame_count += 1\n",
    "            \n",
    "            # 1. RUN HEAVY AI periodically (every 50 frames)\n",
    "            # or on first frame\n",
    "            if frame_count % 50 == 1 or frame_count == 1:\n",
    "                cache['yolo'] = run_yolo(frame)\n",
    "                cache['text'] = run_reva_text(frame)\n",
    "                cache['logo'] = run_reva_logo(frame)\n",
    "                \n",
    "                # Update summary\n",
    "                s = {'YOLO Objects': len(cache['yolo']), 'REVA Text': len(cache['text']), 'REVA Logo': 1 if cache['logo'] else 0}\n",
    "                counts = {}\n",
    "                for (cls, *rest) in cache['yolo']: counts[cls] = counts.get(cls, 0) + 1\n",
    "                s['Top'] = ', '.join(f'{k}:{v}' for k, v in sorted(counts.items(), key=lambda x:-x[1])[:2])\n",
    "                cache['summary'] = s\n",
    "                if s['REVA Text'] or s['REVA Logo']: print(f'*** REVA SPOTTED @ frame {frame_count} ***')\n",
    "\n",
    "            # 2. RUN FAST AI every frame\n",
    "            motion = run_motion(frame)\n",
    "            \n",
    "            # 3. DRAW COMBINED RESULTS\n",
    "            annotated = frame.copy()\n",
    "            # Motion (Live)\n",
    "            for x, y, w, h in motion: draw_box(annotated, x, y, w, h, 'Motion', (0,0,225))\n",
    "            # YOLO (Cached)\n",
    "            for cls, conf, x, y, w, h in cache['yolo']: draw_box(annotated, x, y, w, h, f'{cls}', COCO_COLORS.get(cls, (255,255,255)))\n",
    "            # REVA Text (Cached)\n",
    "            for x, y, w, h, txt in cache['text']: draw_box(annotated, x, y, w, h, f'REVA: {txt}', (0,255,255))\n",
    "            # REVA Logo (Cached)\n",
    "            if cache['logo']: x, y, w, h = cache['logo']; draw_box(annotated, x, y, w, h, 'REVA LOGO', (255,125,0))\n",
    "\n",
    "            # 4. HUD & DISPLAY\n",
    "            curr_time = time.time()\n",
    "            fps = 1.0 / max(curr_time - prev_time, 1e-6)\n",
    "            prev_time = curr_time\n",
    "            \n",
    "            # Title/FPS Overlay\n",
    "            cv2.putText(annotated, f'LIVE | {fps:.1f} FPS | Frame #{frame_count}', (10, 25), 1, 1.2, (0,255,0), 2)\n",
    "            cv2.putText(annotated, f'AI Mode: Decoupled | Next AI in {50 - (frame_count%50)} fr', (10, 50), 1, 1.0, (200,200,200), 1)\n",
    "            \n",
    "            # Show in notebook every ~2 frames to avoid bandwidth lag\n",
    "            if frame_count % 2 == 0:\n",
    "                dh = show_in_notebook(annotated, frame_count, fps, dh)\n",
    "\n",
    "            if max_frames and frame_count >= max_frames: break\n",
    "            \n",
    "    except KeyboardInterrupt: pass\n",
    "    finally: cap.release(); print('Done.')\n",
    "\n",
    "run_surveillance()\n"
]

# ─────────────────────────────────────────────────────────────────────────────
# PATCH THE NOTEBOOK
# ─────────────────────────────────────────────────────────────────────────────
try:
    with open(NB_PATH, 'r', encoding='utf-8') as f:
        nb = json.load(f)

    def patch(nb, cell_id, new_source):
        for cell in nb['cells']:
            if cell.get('id') == cell_id:
                cell['source'] = new_source
                return True
        return False

    patch(nb, 'helpers-cell', HELPERS_SRC)
    patch(nb, 'main-cell', MAIN_SRC)

    with open(NB_PATH, 'w', encoding='utf-8') as f:
        json.dump(nb, f, indent=1, ensure_ascii=False)
    print('SUCCESS: Optimized notebook for LIVE video.')
except Exception as e:
    print('ERROR:', e)
